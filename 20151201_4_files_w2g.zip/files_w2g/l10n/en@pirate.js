OC.L10N.register(
    "files_w2g",
    {
		"File not locked" : "File not locked",
		"File is locked" : "File is locked",
		"Status: locked" : "Status: locked",
		"Status: not locked" : "Status: not locked",
		"filelock" : "filelock"
},
"nplurals=2; plural=(n != 1);");